# x86_asm - Utilities
Various helper scripts to make life a little easier and the blogs easier to follow.

# Related Blog Posts to This Code:
* [Linux X86 Assembly - How To Make Payload Extraction Easier](https://secureideas.com/blog/2021/07/linux-x86-assembly-how-to-make-payload-extraction-easier.html)
* [Linux X86 Assembly – How To Test Custom Shellcode Using a C Payload Tester](https://secureideas.com/blog/2021/09/linux-x86-assembly-how-to-test-custom-shellcode-using-a-c-payload-tester.html)
